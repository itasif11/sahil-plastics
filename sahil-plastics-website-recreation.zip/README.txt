SAHIL PLASTICS STATIC RECREATION
================================
This is an editable static HTML/CSS/JS recreation based on the public structure of sahilplastics.online.

Open index.html in a browser to preview it.
Upload the three files to cPanel/public_html or any static hosting.

IMPORTANT:
- This is NOT the original Shopify backend.
- Cart is demo-only until connected to Shopify/payment/checkout.
- Product image URLs currently point to the public website and may need downloading/replacing with local images.
- Edit products in script.js and text/layout in index.html.
