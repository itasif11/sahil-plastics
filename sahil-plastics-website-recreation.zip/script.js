const products=[
["Deluxe Premium Plastic Gold Floor Mat",345,495,"https://sahilplastics.online/cdn/shop/files/Deluxe_Premium_Plastic_Gold_Floor_Mat.jpg"],
["Deluxe Premium Standard Floor Mat",350,495,"https://sahilplastics.online/cdn/shop/files/Deluxe_Premium_Standard_Floor_mat.jpg"],
["Rangoli Blue Plastic Floor Mat",560,795,"https://sahilplastics.online/cdn/shop/files/Rangoli_Blue_Plastic_Floor_Mat.jpg"],
["Royal Heritage Premium Plastic Floor Mat",610,875,"https://sahilplastics.online/cdn/shop/files/Royal_Heritage_Premium_Plastic_Floor_Mat.jpg"],
["Handy Multipurpose Plastic Foldable Mat",270,545,"https://sahilplastics.online/cdn/shop/files/Handy_Multipurpose_Plastic_Foldable_Mat.jpg"],
["Royal Prestige Floor Mat",610,875,"https://sahilplastics.online/cdn/shop/files/Royal_Prestige_Floor_Mat.jpg"],
["Royal Classic Premium Plastic Floor Mat",610,875,"https://sahilplastics.online/cdn/shop/files/Royal_Classic_Premium_Plastic_Floor_Mat.jpg"],
["Rangoli Orange Plastic Mat",560,795,"https://sahilplastics.online/cdn/shop/files/Rangoli_Orange_plastic_mat.jpg"]
];
const grid=document.getElementById("productGrid");
products.forEach((p,i)=>grid.innerHTML+=`<article class="product"><span class="sale">Sale</span><img src="${p[3]}" alt="${p[0]}" onerror="this.style.display='none';this.parentElement.style.background='#ddd';this.parentElement.style.aspectRatio='1/1'"><h3>${p[0]}</h3><div class="price"><span class="old">Rs. ${p[2]}.00</span> From Rs. ${p[1]}.00 INR</div><button class="btn buy" onclick="addCart('${p[0]}')">Add to cart</button></article>`);
let cart=0;
function addCart(name){cart++;document.getElementById("cartCount").textContent=cart;toast(name+" added to cart");}
function showCart(){toast(cart?`Cart has ${cart} item(s). Connect this button to your Shopify checkout when you migrate.`:"Your cart is empty.");}
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.style.display="block";clearTimeout(window.tt);window.tt=setTimeout(()=>t.style.display="none",2600)}
function searchSite(){const q=prompt("Search products");if(q) location.hash="products";}
function subscribe(e){e.preventDefault();toast("Thanks for subscribing!");e.target.reset()}
function toggleNav(){const n=document.getElementById("nav");n.style.display=n.style.display==="flex"?"none":"flex";}
